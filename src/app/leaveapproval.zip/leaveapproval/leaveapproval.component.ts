import { Component, OnInit, Inject } from '@angular/core';

import { MatTableModule } from '@angular/material/table';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, fadeInContent } from '@angular/material';
import { NgProgress } from 'ngx-progressbar';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { IEmpLeaveDetails, IEMPLeaveApprovalDetails, IEmployeeDetails, ITeamNames, IMasterDetail, IStatusTypes, ILeaveType } from '../leaveapproval/leaveapproval.Interface';
import { LeaveApprovalService } from '../leaveapproval/leaveapproval.service';
import { UserService } from '../users/user.service';
import { Observable } from 'rxjs/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { TeamDashboardService } from '../team-dashboard/team-dashboard.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { getLocaleDateFormat, DatePipe } from '@angular/common';
import{MasterTabsService} from '../master-tabs/master-tabs.service';
import { ImasterTabs } from '../master-tabs/master-tabs.interface';

@Component({
  selector: 'app-leaveapproval',
  templateUrl: './leaveapproval.component.html',
  styleUrls: ['./leaveapproval.component.css'],
  providers: [DatePipe]
})
export class LeaveapprovalComponent implements OnInit {
public MastertabDetails:ImasterTabs[];
  public MasterDetails: IMasterDetail[];
  public LeaveDetails: IEmpLeaveDetails[];
  EmpLeaveApprovalDetails: IEMPLeaveApprovalDetails;
  public LeaveTypeDetails: ILeaveType[];
  public StatusTypeDetails: IStatusTypes[];
  public errorMessage: any;
  public approvereason: string = "Approved";
  public rejectreason: string = "Rejected";
  public myDate: string = new Date().toISOString();
  public isPermission: boolean = false;
  public validationMessage: string;
  public btnflag: boolean = false;
  EmpNamefilteredOptions: Observable<any[]>;
  TeamfilteredOptions: Observable<any[]>;
  public EmployeeDetails: IEmployeeDetails[];
  public EmployeeFilter: IEmployeeDetails[];
  public TeamDetails: ITeamNames[];
  public DefaultEmpName: string;
  public EMPCode: string = "0";
  EmployeeName = new FormControl();
  TeamName = new FormControl();
  public EmpNametext: string = "";
  public Empcodefliter: string = "";
  public EmpTeamnamefliter: string = "";
  public TeamID: any = 0;
  public SelectedName: string;
  public Icon: boolean = true;
  public RoutingEmpID: string = "";
  public RoutingTeamname: string = "";
  public RoutingEMPName: string = "";
  public backbtnflag: boolean = false;
  public FromDate: string;
  public ToDate: string;
  public StatusString: string = "";
  public TeamString: string = "";
  public LeaveTypeString: string = "";
  public TeamFilterString: string = "";
  public IsObjload: boolean = false;
  public TeamNameArray = new Array();
  public StatusArray = new Array();
  public LTypeArray = new Array();
  public HolidayWorkReason:Boolean;
  public OverrideApproval:Boolean=false;
  public OverrideApprovalvalue:Boolean;
  public Approvalvalue:any=0;
  public MenuName:string="";
  public isChecked:boolean=false;
  public Isshowexception:Boolean;
  constructor(public MasterTabsService:MasterTabsService,
    public LeaveApprovalService: LeaveApprovalService,
    public dialog: MatDialog,
    public userService: UserService,
    public ngProgress: NgProgress,
    public snackBar: MatSnackBar,
    public TeamDashboardService: TeamDashboardService,
    private router: Router, private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    public datePipe: DatePipe
  ) {
    this.EmployeeDetails = [
      {

        "EMPID": 0,
        "EMPCODE": "",
        "EMPName": "",
        "TeamID": "",
        "TeamName": ""
      }
    ]

  }
  ///Leave Approval------------
  openApproveDialog(Leave: any): void {
    let ApprovedialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      disableClose: true,
      width: '250px',
      data: { Reason: Leave.LeaveType + '  ' + this.approvereason }

    });
    ApprovedialogRef.afterClosed().subscribe(result => {
      this.approvereason = result;
      this.EmpLeaveApprovalDetails.LeaveApproval = true;
      this.EmpLeaveApprovalDetails.LeaveApproveRemarks = this.approvereason;
      this.EmpLeaveApprovalDetails.LeaveApprovedBy = this.userService.EMPID;
      this.EmpLeaveApprovalDetails.LeaveID = Leave.LeaveID;
      if (this.approvereason != "" && Boolean(this.approvereason) != false) {
        this.SaveLeave();
      }
      else {
        this.validationMessage = "No Action Taken!"
        this.openSnackBar(this.validationMessage, "Close", "warning");
      }
      this.approvereason = "Approved";
    });
  }

  ///Leave Rejection------------
  openRejectDialog(Leave: any): void {
    let RejectdialogRef = this.dialog.open(RejectDialogOverviewExampleDialog, {
      disableClose: true,
      width: '250px',
      data: { Reason: Leave.LeaveType + '  ' + this.rejectreason }
    });

    RejectdialogRef.afterClosed().subscribe(result => {
      this.rejectreason = result;
      this.EmpLeaveApprovalDetails.LeaveApproval = false;
      this.EmpLeaveApprovalDetails.LeaveApproveRemarks = this.rejectreason;
      this.EmpLeaveApprovalDetails.LeaveApprovedBy = this.userService.EMPID;
      this.EmpLeaveApprovalDetails.LeaveID = Leave.LeaveID;
      if (this.rejectreason != "" && Boolean(this.rejectreason) != false) {
        this.SaveLeave();
      }
      else {
        this.validationMessage = "No Action Taken!"
        this.openSnackBar(this.validationMessage, "Close", "warning");
      }
      this.rejectreason = "Rejected";
    });
  }

  Overrideapproval(){
    debugger;
    this.MasterTabsService.GetMasterTabDetails(this.userService.EMPCode)
    .subscribe(data => {
      debugger;
      this.MastertabDetails=data;
    

    if (this.MastertabDetails.find(x => x.MenuName=='LeaveApproval')&&this.MastertabDetails.find(x=>x.CanOverRideApproval==1))  {
this.OverrideApproval=true;
      }  

    });
  }

  ngOnInit() {
    debugger;
    this.spinner.show();
    this.Overrideapproval()
    this.FromDate = new Date().toISOString();
    this.ToDate = new Date().toISOString();
    this.RoutingTeamname = this.route.snapshot.paramMap.get("TeamName");
    this.RoutingEmpID = this.route.snapshot.paramMap.get("EMPCode");
    this.RoutingEMPName = this.route.snapshot.paramMap.get("EMPName");
    if ((this.RoutingEMPName != null) && (this.RoutingTeamname != null)) {
      this.backbtnflag = true;
      this.Empcodefliter = this.RoutingEMPName;
      this.EmpTeamnamefliter = this.RoutingTeamname;
    }

    this.cleardetails();
    this.GoSearch();
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }

  //Grid Search Event------------------------------------------------
  GoSearch() {
    if (this.FromDate == null) {
      this.FromDate = "";
    }
    if (this.ToDate == null) {
      this.ToDate = "";
    }
    this.IsObjload = true
    this.GetEmployeeLeaveDetails(this.userService.EMPCode, this.FromDate, this.ToDate, this.EMPCode, this.TeamString, this.LeaveTypeString, this.StatusString);
  }

  //Get Leave Details------------------------------------------------
  GetEmployeeLeaveDetails(Loggeduser, FromDate, ToDate, Empcode, TeamID: string, LeaveType, LeaveStatus) {
    debugger
    this.spinner.show();
    if (FromDate != "") {
      FromDate = this.datePipe.transform(FromDate, 'yyyy-MM-dd');
    }
    if (ToDate != "") {
      ToDate = this.datePipe.transform(ToDate, 'yyyy-MM-dd');
    }
    this.LeaveApprovalService.getEmployeeLeaveDetails(Loggeduser, FromDate, ToDate, Empcode, TeamID, LeaveType, LeaveStatus,this.Approvalvalue)
      .subscribe((data: IMasterDetail) => {
        debugger;
        this.LeaveDetails = data.LeaveDetails;

        this.EmployeeDetails = data.EmployeeDetails;
// if(this.LeaveDetails[0].AppliedLeaveRemarks!=="" && this.LeaveDetails[0].LeaveType=="Comp Off Leave"){
// this.HolidayWorkReason=true;
// }else{
//   this.HolidayWorkReason=false;
// }
this.HolidayWorkReason=true;
        if (this.Empcodefliter == "" || this.Empcodefliter == "ALL") {
          this.Empcodefliter = this.EmployeeDetails[0].EMPName
        }
        if (this.EMPCode == '0') {
          this.EMPCode = this.EmployeeDetails[0].EMPCODE;
        }
        this.EmpNamefilteredOptions = this.EmployeeName.valueChanges
          .pipe(
            startWith(''),
            map(empName => empName ? this.filterNames(empName) : this.EmployeeDetails.slice())
          );
        if (this.IsObjload == true) {
          this.TeamDetails = data.TeamDetails;
          this.StatusTypeDetails = data.StatusTypeDetails;
          this.LeaveTypeDetails = data.LeaveTypeDetails;
        }
        this.IsObjload = false
      },
        error => alert('Error: ' + <any>error));
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }
  //Employee change event-----------------------------------
  EmployeeChange(EName: string) {
    this.spinner.show();
    this.EmployeeFilter = this.EmployeeDetails.filter(empName =>
      empName.EMPName.toLowerCase().indexOf(EName.toLowerCase()) === 0);
    this.EMPCode = this.EmployeeFilter[0].EMPCODE;
    this.Empcodefliter = this.EmployeeFilter[0].EMPName;
    this.GetEmployeeLeaveDetails(this.userService.EMPCode, this.FromDate, this.ToDate, this.EMPCode, this.TeamString, this.LeaveTypeString, this.StatusString);
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }
  //Leave Type change event----------------------------------------
  LTypeChanges(LTypes: any) {
    const index: number = this.LTypeArray.indexOf(LTypes.LeaveTypeID);
    if (index !== -1) {
      this.LTypeArray.splice(index, 1);
    }
    else
      this.LTypeArray.push(LTypes.LeaveTypeID)

    this.LeaveTypeString = ""
    this.LTypeArray.forEach(data => {

      if (this.LeaveTypeString.length == 0) {
        this.LeaveTypeString = data;
      }
      else {
        this.LeaveTypeString = this.LeaveTypeString + "," + data
      }

    })

    this.GetEmployeeLeaveDetails(this.userService.EMPCode, this.FromDate, this.ToDate, this.EMPCode, this.TeamString, this.LeaveTypeString, this.StatusString);
  }

  //Team Name change event----------------------------------------
  TNameChanges(TNames: any) {
    const index: number = this.TeamNameArray.indexOf(TNames.TeamID);
    if (index !== -1) {
      this.TeamNameArray.splice(index, 1);
    }
    else
      this.TeamNameArray.push(TNames.TeamID)

    this.TeamString = ""
    this.TeamNameArray.forEach(data => {

      if (this.TeamString.length == 0) {
        this.TeamString = data;
      }
      else {
        this.TeamString = this.TeamString + "," + data
      }

    })

    this.GetEmployeeLeaveDetails(this.userService.EMPCode, this.FromDate, this.ToDate, this.EMPCode, this.TeamString, this.LeaveTypeString, this.StatusString);

  }
  //Isexception Leave checked
  ExceptionValue(event, Leave){
    debugger;
    Leave.isChecked=event.checked;

  }
  //Status Type change event----------------------------------------
  StatusChanges(STypes: any) {
    const index: number = this.StatusArray.indexOf(STypes.StatusID);
    if (index !== -1) {
      this.StatusArray.splice(index, 1);
    }
    else
      this.StatusArray.push(STypes.StatusID)

    this.StatusString = ""
    this.StatusArray.forEach(data => {

      if (this.StatusString.length == 0) {
        this.StatusString = data;
      }
      else {
        this.StatusString = this.StatusString + "," + data
      }

    })
    this.GetEmployeeLeaveDetails(this.userService.EMPCode, this.FromDate, this.ToDate, this.EMPCode, this.TeamString, this.LeaveTypeString, this.StatusString);
  }

  filterNames(name: string) {
    return this.EmployeeDetails.filter(empName =>
      empName.EMPName.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }
  Togglechange(){
    // debugger;
    // if(this.OverrideApprovalvalue=="true"){
      
    // }

    this.spinner.show();
    if(this.OverrideApprovalvalue==true){
this.Approvalvalue=1;
    }
    else{
      this.Approvalvalue=0;
    }
    debugger;
    this.LeaveApprovalService.getEmployeeLeaveDetails(this.userService.EMPCode,this.FromDate, this.ToDate, this.EMPCode,this.TeamString, this.LeaveTypeString, this.StatusString,this.Approvalvalue)
    .subscribe((data: IMasterDetail) => {
  
      this.LeaveDetails = data.LeaveDetails;

      this.EmployeeDetails = data.EmployeeDetails;
// if(this.LeaveDetails[0].AppliedLeaveRemarks!=="" && this.LeaveDetails[0].LeaveType=="Comp Off Leave"){
// this.HolidayWorkReason=true;
// }else{
//   this.HolidayWorkReason=false;
// }
this.HolidayWorkReason=true;
      if (this.Empcodefliter == "" || this.Empcodefliter == "ALL") {
        this.Empcodefliter = this.EmployeeDetails[0].EMPName
      }
      if (this.EMPCode == '0') {
        this.EMPCode = this.EmployeeDetails[0].EMPCODE;
      }
      this.EmpNamefilteredOptions = this.EmployeeName.valueChanges
        .pipe(
          startWith(''),
          map(empName => empName ? this.filterNames(empName) : this.EmployeeDetails.slice())
        );
      if (this.IsObjload == true) {
        this.TeamDetails = data.TeamDetails;
        this.StatusTypeDetails = data.StatusTypeDetails;
        this.LeaveTypeDetails = data.LeaveTypeDetails;
      }
      this.IsObjload = false
    },
      error => alert('Error: ' + <any>error));
  setTimeout(() => {
    this.spinner.hide();
  }, 500);
  }
  //Open filter event---------------------------------------------------
  openNav() {
    var sidenav = document.getElementById('sidenadiv');
    var detailgriddiv = document.getElementById('detailgriddiv');
    var filterbtn = document.getElementById('filterbtn');
    var closebtn = document.getElementById('closebtn');
    sidenav.style.width = "280px";
    sidenav.style.top = "90px";
    sidenav.style.overflow = "auto";
    detailgriddiv.style.marginLeft = "200px";
    document.body.style.backgroundColor = "white";
    filterbtn.style.display = "none";
    closebtn.style.display = "block";
  }

  //Close filter Event------------------------------------
  closeNav() {
    var sidenav = document.getElementById('sidenadiv');
    var detailgriddiv = document.getElementById('detailgriddiv');
    var filterbtn = document.getElementById('filterbtn');
    var closebtn = document.getElementById('closebtn');
    sidenav.style.width = "0px";
    sidenav.style.top = "0px";
    sidenav.style.overflow = "auto";
    detailgriddiv.style.marginLeft = "0px";
    document.body.style.backgroundColor = "white";
    filterbtn.style.display = "block";
    closebtn.style.display = "none";

  }

  SaveLeave() {
    debugger;

    this.spinner.show();
    this.EmpLeaveApprovalDetails;
    //this.EmpLeaveApprovalDetails.IsException=this.isChecked;
    this.LeaveApprovalService.CommitLeave(this.EmpLeaveApprovalDetails)
      .subscribe(
        result => {
          this.EmpLeaveApprovalDetails = <IEMPLeaveApprovalDetails>result
          this.validationMessage = this.EmpLeaveApprovalDetails.Description;
          if (this.EmpLeaveApprovalDetails.Status.toUpperCase() == "SUCCESS") {
            this.openSnackBar(this.validationMessage, "Close", 'success');
          }
          else {
            this.openSnackBar(this.validationMessage, "Close", 'error');
          }
          this.approvereason = "Approved";
          this.rejectreason = "Rejected";
          this.cleardetails();
          this.GetEmployeeLeaveDetails(this.userService.EMPCode, this.FromDate, this.ToDate, this.EMPCode, this.TeamString, this.LeaveTypeString, this.StatusString);
        },
        error => {
          this.errorMessage = <any>error
          alert(this.errorMessage);
        },

    )
  }
  cleardetails() {
    this.EmpLeaveApprovalDetails =
      {
        "LeaveApproval": false,
        "LeaveApproveRemarks": "",
        "LeaveApprovedBy": 0,
        "LeaveID": 0,
        "Status": "",
        "Description": "",
        "IsException":false
      };
  }
  openSnackBar(message: string, action: string, messagetype: string) {
    let config = new MatSnackBarConfig();
    config.extraClasses = [messagetype + '-class'];
    config.duration = 3000;
    config.verticalPosition = 'top';
    config.horizontalPosition = 'center';
    this.snackBar.open(message, action, config);
  }


  GetEmployeeNamedetails(EMPCode) {
    this.spinner.show();
    this.LeaveApprovalService.getEmployeeNameDetails(EMPCode)
      .subscribe((data: IEmployeeDetails[]) => {
        this.EmployeeDetails = data;
        this.EmployeeDetails.splice(0, 1);
        //this.EMPCode = this.EmployeeDetails[0].EMPCODE;
        this.EmpNamefilteredOptions = this.EmployeeName.valueChanges
          .pipe(
            startWith(''),
            map(empName => empName ? this.filterNames(empName) : this.EmployeeDetails.slice())
          );
      }, error => this.errorMessage = <any>error);
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }
  backClicked() {
    this.spinner.show();
    window.history.back();
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }
}

@Component({
  selector: 'approve-dialog',
  templateUrl: 'approve-dialog.html',
})
export class DialogOverviewExampleDialog {

  constructor(
    public ApprovedialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.ApprovedialogRef.close();
  }
}

@Component({
  selector: 'reject-dialog',
  templateUrl: 'reject-dialog.html',
})
export class RejectDialogOverviewExampleDialog {

  constructor(
    public RejectdialogRef: MatDialogRef<RejectDialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.RejectdialogRef.close();

  }

}
